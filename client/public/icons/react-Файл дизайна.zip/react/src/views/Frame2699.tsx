import "@/styles/Frame2699.css";
const Frame2699 = () => {
    return (
        <div className="scroll-container">
            <div
                id="2_699"
                className="Pixso-frame-2_699 pixso-relative-no-shrink pixso-flex"
            >
                <div
                    id="2_700"
                    className="Pixso-frame-2_700 pixso-relative-no-shrink pixso-flex"
                >
                    <div className="frame-content-2_700 pixso-relative-flex">
                        <p
                            id="2_701"
                            className="Pixso-paragraph-2_701 pixso-relative-auto-size pixso-flex-shrink-0"
                        >
                            {"9:41"}
                        </p>
                        <div
                            id="2_702"
                            className="Pixso-frame-2_702 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                        >
                            <div
                                id="2_703"
                                className="Pixso-vector-2_703 pixso-relative-no-shrink"
                            ></div>
                            <div
                                id="2_709"
                                className="Pixso-vector-2_709 pixso-relative-no-shrink"
                            ></div>
                            <div
                                id="2_714"
                                className="Pixso-frame-2_714 pixso-relative-no-shrink"
                            >
                                <div
                                    id="2_715"
                                    className="Pixso-vector-2_715"
                                ></div>
                                <div
                                    id="2_716"
                                    className="Pixso-vector-2_716"
                                ></div>
                                <div
                                    id="2_717"
                                    className="Pixso-vector-2_717"
                                ></div>
                                <div
                                    id="2_718"
                                    className="Pixso-vector-2_718"
                                ></div>
                                <div
                                    id="2_719"
                                    className="stroke-wrapper-2_719"
                                >
                                    <div className="Pixso-rectangle-2_719 pixso-position-relative"></div>
                                    <div className="stroke-2_719"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    id="2_720"
                    className="Pixso-frame-2_720 pixso-relative-no-shrink pixso-flex"
                >
                    <div className="frame-content-2_720 pixso-relative-flex">
                        <p
                            id="2_721"
                            className="Pixso-paragraph-2_721 pixso-relative-auto-size pixso-flex-shrink-0"
                        >
                            {"Профиль"}
                        </p>
                        <div
                            id="2_722"
                            className="Pixso-vector-2_722 pixso-relative-no-shrink"
                        ></div>
                    </div>
                </div>
                <div
                    id="2_726"
                    className="Pixso-frame-2_726 pixso-relative-no-shrink pixso-flex"
                >
                    <div className="frame-content-2_726 pixso-relative-flex">
                        <div
                            id="2_727"
                            className="Pixso-frame-2_727 pixso-relative-no-shrink pixso-flex-auto-height"
                        >
                            <div className="frame-content-2_727 pixso-relative-flex">
                                <div
                                    id="2_728"
                                    className="stroke-wrapper-2_728 pixso-relative-no-shrink"
                                >
                                    <div className="Pixso-frame-2_728 pixso-relative-no-shrink"></div>
                                    <div className="stroke-2_728"></div>
                                </div>
                                <div
                                    id="2_729"
                                    className="Pixso-frame-2_729 pixso-relative-no-shrink pixso-flex-auto-height"
                                >
                                    <div className="frame-content-2_729 pixso-relative-flex">
                                        <p
                                            id="2_730"
                                            className="Pixso-paragraph-2_730 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"Марина Соловьёва"}
                                        </p>
                                        <p
                                            id="2_731"
                                            className="Pixso-paragraph-2_731 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"@marina.sol"}
                                        </p>
                                    </div>
                                </div>
                                <p
                                    id="2_732"
                                    className="Pixso-paragraph-2_732 pixso-relative-no-shrink pixso-h-auto"
                                >
                                    {
                                        "Веб-разработка, 3 курс. Фотографирую город по вечерам, собираю плейлисты и командные проекты."
                                    }
                                </p>
                                <div
                                    id="2_733"
                                    className="Pixso-frame-2_733 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                                >
                                    <div
                                        id="2_734"
                                        className="Pixso-vector-2_734 pixso-relative-no-shrink"
                                    ></div>
                                    <p
                                        id="2_738"
                                        className="Pixso-paragraph-2_738 pixso-relative-auto-size pixso-flex-shrink-0"
                                    >
                                        {"МГТУ · Пи-21-1"}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div
                            id="2_739"
                            className="stroke-wrapper-2_739 pixso-relative-no-shrink pixso-flex"
                        >
                            <div className="Pixso-frame-2_739 pixso-relative-no-shrink pixso-flex">
                                <div className="frame-content-2_739 pixso-relative-flex">
                                    <div
                                        id="2_740"
                                        className="Pixso-frame-2_740 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                                    >
                                        <p
                                            id="2_741"
                                            className="Pixso-paragraph-2_741 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"48"}
                                        </p>
                                        <p
                                            id="2_742"
                                            className="Pixso-paragraph-2_742 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"публикаций"}
                                        </p>
                                    </div>
                                    <div
                                        id="2_743"
                                        className="Pixso-frame-2_743 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                                    >
                                        <p
                                            id="2_744"
                                            className="Pixso-paragraph-2_744 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"4"}
                                        </p>
                                        <p
                                            id="2_745"
                                            className="Pixso-paragraph-2_745 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"группы"}
                                        </p>
                                    </div>
                                    <div
                                        id="2_746"
                                        className="Pixso-frame-2_746 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                                    >
                                        <p
                                            id="2_747"
                                            className="Pixso-paragraph-2_747 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"126"}
                                        </p>
                                        <p
                                            id="2_748"
                                            className="Pixso-paragraph-2_748 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"друзей"}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className="stroke-2_739"></div>
                        </div>
                        <div
                            id="2_749"
                            className="Pixso-frame-2_749 pixso-relative-no-shrink pixso-flex-auto-height"
                        >
                            <div className="frame-content-2_749 pixso-relative-flex">
                                <div
                                    id="2_750"
                                    className="Pixso-frame-2_750 pixso-relative-flex"
                                >
                                    <div className="frame-content-2_750 pixso-relative-flex">
                                        <div
                                            id="2_751"
                                            className="Pixso-vector-2_751 pixso-relative-no-shrink"
                                        ></div>
                                        <p
                                            id="2_754"
                                            className="Pixso-paragraph-2_754 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"Редактировать"}
                                        </p>
                                    </div>
                                </div>
                                <div
                                    id="2_755"
                                    className="stroke-wrapper-2_755 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="Pixso-frame-2_755 pixso-relative-no-shrink pixso-flex">
                                        <div className="frame-content-2_755 pixso-relative-flex">
                                            <div
                                                id="2_756"
                                                className="Pixso-vector-2_756 pixso-relative-no-shrink"
                                            ></div>
                                        </div>
                                    </div>
                                    <div className="stroke-2_755"></div>
                                </div>
                            </div>
                        </div>
                        <div
                            id="2_759"
                            className="Pixso-frame-2_759 pixso-relative-no-shrink pixso-flex-auto-height"
                        >
                            <div className="frame-content-2_759 pixso-relative-flex">
                                <div
                                    id="2_760"
                                    className="Pixso-frame-2_760 pixso-relative-flex"
                                >
                                    <div className="frame-content-2_760 pixso-relative-flex">
                                        <p
                                            id="2_761"
                                            className="Pixso-paragraph-2_761 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"Публикации"}
                                        </p>
                                    </div>
                                </div>
                                <div
                                    id="2_762"
                                    className="Pixso-frame-2_762 pixso-relative-flex"
                                >
                                    <div className="frame-content-2_762 pixso-relative-flex">
                                        <p
                                            id="2_763"
                                            className="Pixso-paragraph-2_763 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"Фото"}
                                        </p>
                                    </div>
                                </div>
                                <div
                                    id="2_764"
                                    className="Pixso-frame-2_764 pixso-relative-flex"
                                >
                                    <div className="frame-content-2_764 pixso-relative-flex">
                                        <p
                                            id="2_765"
                                            className="Pixso-paragraph-2_765 pixso-relative-auto-size pixso-flex-shrink-0"
                                        >
                                            {"Музыка"}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            id="2_766"
                            className="Pixso-frame-2_766 pixso-relative-no-shrink pixso-flex-auto-height"
                        >
                            <div className="frame-content-2_766 pixso-relative-flex">
                                <div
                                    id="2_767"
                                    className="Pixso-rectangle-2_767 pixso-relative-no-shrink"
                                ></div>
                                <div
                                    id="2_768"
                                    className="Pixso-rectangle-2_768 pixso-relative-no-shrink"
                                ></div>
                                <div
                                    id="2_769"
                                    className="Pixso-rectangle-2_769 pixso-relative-no-shrink"
                                ></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    id="2_770"
                    className="stroke-wrapper-2_770 pixso-relative-no-shrink pixso-flex"
                >
                    <div className="Pixso-frame-2_770 pixso-relative-no-shrink pixso-flex">
                        <div className="frame-content-2_770 pixso-relative-flex">
                            <div
                                id="2_771"
                                className="Pixso-frame-2_771 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                            >
                                <div
                                    id="2_772"
                                    className="Pixso-frame-2_772 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="frame-content-2_772 pixso-relative-flex">
                                        <div
                                            id="2_773"
                                            className="Pixso-vector-2_773 pixso-relative-no-shrink"
                                        ></div>
                                    </div>
                                </div>
                                <p
                                    id="2_776"
                                    className="Pixso-paragraph-2_776 pixso-relative-auto-size pixso-flex-shrink-0"
                                >
                                    {"Лента"}
                                </p>
                            </div>
                            <div
                                id="2_777"
                                className="Pixso-frame-2_777 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                            >
                                <div
                                    id="2_778"
                                    className="Pixso-frame-2_778 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="frame-content-2_778 pixso-relative-flex">
                                        <div
                                            id="2_779"
                                            className="Pixso-vector-2_779 pixso-relative-no-shrink"
                                        ></div>
                                    </div>
                                </div>
                                <p
                                    id="2_781"
                                    className="Pixso-paragraph-2_781 pixso-relative-auto-size pixso-flex-shrink-0"
                                >
                                    {"Чаты"}
                                </p>
                            </div>
                            <div
                                id="2_782"
                                className="Pixso-frame-2_782 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                            >
                                <div
                                    id="2_783"
                                    className="Pixso-frame-2_783 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="frame-content-2_783 pixso-relative-flex">
                                        <div
                                            id="2_784"
                                            className="Pixso-vector-2_784 pixso-relative-no-shrink"
                                        ></div>
                                    </div>
                                </div>
                                <p
                                    id="2_789"
                                    className="Pixso-paragraph-2_789 pixso-relative-auto-size pixso-flex-shrink-0"
                                >
                                    {"Группы"}
                                </p>
                            </div>
                            <div
                                id="2_790"
                                className="Pixso-frame-2_790 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                            >
                                <div
                                    id="2_791"
                                    className="Pixso-frame-2_791 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="frame-content-2_791 pixso-relative-flex">
                                        <div
                                            id="2_792"
                                            className="Pixso-vector-2_792 pixso-relative-no-shrink"
                                        ></div>
                                    </div>
                                </div>
                                <p
                                    id="2_795"
                                    className="Pixso-paragraph-2_795 pixso-relative-auto-size pixso-flex-shrink-0"
                                >
                                    {"Увед."}
                                </p>
                            </div>
                            <div
                                id="2_796"
                                className="Pixso-frame-2_796 pixso-relative-flex-auto-size pixso-flex-shrink-0"
                            >
                                <div
                                    id="2_797"
                                    className="Pixso-frame-2_797 pixso-relative-no-shrink pixso-flex"
                                >
                                    <div className="frame-content-2_797 pixso-relative-flex">
                                        <div
                                            id="2_798"
                                            className="Pixso-vector-2_798 pixso-relative-no-shrink"
                                        ></div>
                                    </div>
                                </div>
                                <p
                                    id="2_801"
                                    className="Pixso-paragraph-2_801 pixso-relative-auto-size pixso-flex-shrink-0"
                                >
                                    {"Профиль"}
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="stroke-2_770"></div>
                </div>
            </div>
        </div>
    );
};
export default Frame2699;
